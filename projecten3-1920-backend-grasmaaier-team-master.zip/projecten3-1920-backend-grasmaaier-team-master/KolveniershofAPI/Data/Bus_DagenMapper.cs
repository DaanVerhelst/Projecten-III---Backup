﻿using KolveniershofAPI.Model.Model_EF;
using Microsoft.EntityFrameworkCore;

namespace KolveniershofAPI.Data
{
    internal class Bus_DagenMapper : IEntityTypeConfiguration<Bus_Dag>
    {
    }
}