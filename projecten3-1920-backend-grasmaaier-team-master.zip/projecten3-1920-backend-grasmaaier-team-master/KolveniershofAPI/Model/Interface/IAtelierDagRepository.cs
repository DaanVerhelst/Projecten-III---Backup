﻿using KolveniershofAPI.Model.Model_EF;

namespace KolveniershofAPI.Model.Interface{
    public interface IAtelierDagRepository{
        void Delete(Atelier_Dag ad);
    }
}
