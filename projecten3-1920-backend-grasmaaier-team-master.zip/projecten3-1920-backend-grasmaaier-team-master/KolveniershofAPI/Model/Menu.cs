﻿using System;
namespace KolveniershofAPI.Model
{
    public class Menu
    {
        public Menu()
        {
        }
    }
}
