export const enum Modes {
    Default,
    Login,
    Admin_Start,
    Admin
}
