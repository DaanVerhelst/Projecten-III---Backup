export interface IBus {
    busID: number;
    naam?: string;
    begeleiders?: number[];
    clienten?: number[];
    start?: string;
    eind?: string;
    voorMnaM?: number;
}
