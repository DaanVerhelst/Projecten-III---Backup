export interface IStringKeyStore {
    key: string;
    value: any;
}
