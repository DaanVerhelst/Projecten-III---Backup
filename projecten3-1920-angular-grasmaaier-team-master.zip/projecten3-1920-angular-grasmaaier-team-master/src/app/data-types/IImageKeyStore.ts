export interface IImageKeyStore {
    id: number;
    image: Blob;
}
