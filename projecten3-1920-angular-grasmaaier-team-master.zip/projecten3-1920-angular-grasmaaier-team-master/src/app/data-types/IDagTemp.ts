import { IDagAtelierTemp } from './IDagAtelierTemp';

export interface IDagTemp {
    date: string;
    ateliers: IDagAtelierTemp[];
}
