export interface INumberKeyStore {
    key: number;
    value?: any;
}
