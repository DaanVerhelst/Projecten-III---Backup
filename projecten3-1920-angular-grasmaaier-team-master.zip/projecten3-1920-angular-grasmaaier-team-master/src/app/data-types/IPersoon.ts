export interface IPersoon {
    id?: number;
    voornaam: string;
    familienaam: string;
    selected?: boolean;
    email?: string;
    password?: string;
}
