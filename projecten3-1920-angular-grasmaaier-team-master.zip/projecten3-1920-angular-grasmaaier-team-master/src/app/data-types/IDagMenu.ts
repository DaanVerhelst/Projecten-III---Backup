export interface IDagMenu {
    id: number;
    dagNr: number;
    dagNaam: string;
    groente?: string;
    vlees?: string;
    soep?: string;
    supplement?: string;
}
