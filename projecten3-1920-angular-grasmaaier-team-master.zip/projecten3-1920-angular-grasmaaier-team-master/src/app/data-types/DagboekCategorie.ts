export enum DagboekCategorie {
    AtelierWeekSchema = 'AtelierWeekSchema',
    Begeleiding = 'Begeleiding',
    Clienten = 'Clienten',
    Logistiek = 'Logistiek',
    Varia = 'Varia',
    Vervoer = 'Vervoer'
}
