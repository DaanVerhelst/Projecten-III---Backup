export interface IAtelier {
    atelierID: number;
    naam?: string;
    start?: string;
    eind?: string;
    begeleides?: number[];
    clienten?: number[];
    voorMnaM?: number;
}
