package be.grasmaaier.kolveniershof

import org.junit.Test

class ClientsTest {

    @Test
    fun writeToParcel_CorrectParcel_ReturnsCorrectValues() {

    }
}