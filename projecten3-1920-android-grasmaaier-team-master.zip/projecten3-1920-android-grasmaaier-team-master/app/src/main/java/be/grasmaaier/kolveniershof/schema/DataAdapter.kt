package be.grasmaaier.kolveniershof.schema

interface DataAdapter {
    fun setDagData(data : List<DagProperty>)
}