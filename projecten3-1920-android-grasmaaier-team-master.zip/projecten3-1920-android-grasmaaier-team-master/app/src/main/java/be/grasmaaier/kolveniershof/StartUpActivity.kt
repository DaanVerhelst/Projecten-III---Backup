package be.grasmaaier.kolveniershof

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class StartUpActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start_up)
    }

}
