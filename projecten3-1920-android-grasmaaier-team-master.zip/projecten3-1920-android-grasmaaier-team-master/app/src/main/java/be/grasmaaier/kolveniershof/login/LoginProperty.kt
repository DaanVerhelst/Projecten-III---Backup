package be.grasmaaier.kolveniershof.login

data class LoginProperty(
    val email: String,
    val password: String
)